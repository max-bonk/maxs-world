import * as React from 'react';
import { Button } from 'react-native';
import { Text, View, StyleSheet } from 'react-native';
export default function App() {
  const [randnum, setRandnum] = React.useState();
  const onGenerateRandom = () => {
    setRandnum(Math.floor(Math.random() * 10000));
  };
    const helloworld = () => {
    setRandnum("HelloWorld!");
  };
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>{randnum}</Text>
      <Button
        onPress={onGenerateRandom}
        title="Generate Number"
        color="#841584"
        accessibilityLabel="Click this button to generate a random number"
      />
      <Button
        onPress={helloworld}
        title="Helloworld!"
        color="#cf1515"
        accessibilityLabel="Click this button to display helloworld!"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#00ffd5',
    padding: 10,
  },
  paragraph: {
    margin: 25,
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: '20',
  },
});

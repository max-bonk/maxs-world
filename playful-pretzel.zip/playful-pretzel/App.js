import * as React from 'react';
import { Text, TextInput, View, StyleSheet } from 'react-native';
export default function App() {
  const [guess, setGuess] = React.useState(0);
  const [mystery, setMystery] = React.useState(Math.floor(Math.random()*10).toString());
  const [result, setResult] = React.useState("Guess my number");
  const onGuess = (newGuess) => {
    setGuess(newGuess);
     if (newGuess === mystery){
      setResult("Great job you magically guessed it correctly");
    } else {
      setResult("lol not even close. try again.");
    }

  };
  return (
    <View style={styles.container}>
      <Text      style={styles.paragraph}
>Guess my number </Text>
      <TextInput
      style={styles.input}
        onChangeText={onGuess}
        value={guess}
        keyboardType="number-pad"
      />
         <Text style={styles.paragraph}>
        {result}
      </Text>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 30,
    fontSize: 23,
    fontWeight: 'bold',
    textAlign: 'center',
  },
       input: {
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },

});
